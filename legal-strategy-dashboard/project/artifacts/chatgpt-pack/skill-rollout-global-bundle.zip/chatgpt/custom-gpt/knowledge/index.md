# Knowledge Index

## Adobe references
- adobe/input_schema.md
- adobe/chatgpt_connector_playbook.md
- adobe/strict_legal_quality_gates.md
- adobe/executive_layout_spec.md
- adobe/adobe_api_fallback.md

## Canva references
- canva/canva_sdk_playbook.md
- canva/template_enforcement.md
- canva/placeholder_mapping.md
- canva/portal_code_upload.md
- canva/skill_chaining_contract.md
